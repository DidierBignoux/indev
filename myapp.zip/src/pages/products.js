import React from 'react';



function Home() {
  return (
    <div className='container'>
        <h1>Productss</h1>
    </div>
  );
}

export default Home;
